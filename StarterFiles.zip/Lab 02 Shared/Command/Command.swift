//
//  Command.swift
//  Lab 02 iOS
//
//  Created by Kaela  Murphy  on 2025-01-13.
//

protocol Command{
    func execute()
    func undo()
}
