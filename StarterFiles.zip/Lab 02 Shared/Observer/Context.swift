//
//  Context.swift
//  Lab 02 iOS
//
//  Created by Kaela  Murphy  on 2025-01-10.
//
import SpriteKit

protocol Context {
    
}
