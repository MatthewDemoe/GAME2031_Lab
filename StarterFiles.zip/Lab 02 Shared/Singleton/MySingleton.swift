//
//  MySingleton.swift
//  Lab 02 iOS
//
//  Created by Kaela  Murphy  on 2025-01-12.
//

class MySingleton {
    static let instance = MySingleton()
    private init() { }
}
